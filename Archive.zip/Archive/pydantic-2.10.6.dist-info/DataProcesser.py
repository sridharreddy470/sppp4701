import json
import openpyxl
import snowflake.connector
from io import BytesIO
from datetime import datetime
from fastapi import FastAPI, File, UploadFile
import uvicorn
from fastapi.middleware.cors import CORSMiddleware
app = FastAPI()
# Snowflake connection config
SNOWFLAKE_ACCOUNT = 'rsb34842.us-east-1'
SNOWFLAKE_USER = 'reddymarch20254701'
SNOWFLAKE_PASSWORD = 'Satish@04130420'
SNOWFLAKE_DATABASE = 'TESTDATA'
SNOWFLAKE_SCHEMA = 'config'
# SNOWFLAKE_WAREHOUSE = 'COMPUTER_WH'

origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_snowflake_connection():
    return snowflake.connector.connect(
        user=SNOWFLAKE_USER,
        password=SNOWFLAKE_PASSWORD,
        account=SNOWFLAKE_ACCOUNT,
        # warehouse=SNOWFLAKE_WAREHOUSE,
        database=SNOWFLAKE_DATABASE,
        schema=SNOWFLAKE_SCHEMA
    )

def lambda_handler(event, context):
    method = event['httpMethod']
    
    if method == 'POST':
        return handle_excel_upload(event)
    elif method == 'GET':
        return handle_get_data(event)
@app.get("/")
def read_root():
    return {"message": "Hello, World"}

@app.post("/post-data")
async def handle_excel_upload(event=None, file: UploadFile = File(...)):
    try:
        # body = event['body']
        # file_data = body.encode('utf-8')  # Assume file is sent in base64
        file_data = await file.read()
        file = BytesIO(file_data)
        wb = openpyxl.load_workbook(file)
        sheet = wb.active
        
        conn = get_snowflake_connection()
        cursor = conn.cursor()
        
        for row in sheet.iter_rows(min_row=2, values_only=True):  # Skipping header row
            # Assuming first column is an ENTITY_DB
            entity_db = row[0]
            data = row[1:]

            check_query = f"SELECT * FROM ENTITY_DETAILS WHERE ENTITY_DB = %s AND ENTITY_SCHEMA = %s AND ENTITY_NAME = %s"
            # Check if the row already exists in the database
            cursor.execute(check_query, (entity_db, data[0], data[1]))
            result = cursor.fetchone()
            
            if result:
                # Update the existing record
                update_query = f"UPDATE ENTITY_DETAILS SET S3_PATH = %s, S3_STORAGE_TYPE = %s WHERE ENTITY_DB = %s AND ENTITY_SCHEMA = %s AND ENTITY_NAME = %s"
                cursor.execute(update_query, (data[2], data[3], entity_db, data[0], data[1]))
            else:
                # Insert new record
                insert_query = f"INSERT INTO ENTITY_DETAILS (ENTITY_DB, ENTITY_SCHEMA, ENTITY_NAME, S3_PATH, S3_STORAGE_TYPE) VALUES (%s, %s, %s, %s, %s)"
                cursor.execute(insert_query, (entity_db, data[0], data[1], data[2], data[3]))
        
        cursor.close()
        conn.commit()
        conn.close()

        return {
            'statusCode': 200,
            'body': {"message": "Excel data processed successfully"}
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({"message": str(e)})
        }

@app.get("/get-data")
def handle_get_data(event=None,page='1',limit='10',filter='',sort='{\"ENTITY_DB\":\"asc\"}'):
    try:
        # page = int(event['queryStringParameters'].get('page', 1))
        # limit = int(event['queryStringParameters'].get('limit', 10))
        # filter = event['queryStringParameters'].get('filter', '')
        # sort = event['queryStringParameters'].get('sort', '')
        page = int(page)
        if page < 1:
          page = 1
        limit = int(limit)
        offset = (page - 1) * limit
        conn = get_snowflake_connection()
        cursor = conn.cursor()
        sortField = "ENTITY_DB"
        sortOrder = "ASC"
        where_clause = ""
        
        params = {}
        if filter:
            filter = json.loads(filter)
            if filter:
                where_clause += " AND ("
                for i, f in enumerate(filter):
                    if i > 0:
                        where_clause += " AND "
                    for key, value in f.items():
                        # Dynamically building where_clause based on filter conditions
                        where_clause += f"{key} LIKE %({key})s "  # Use parameterized query for security
                        params[key] = f"%{value}%"  # Store the sort order in the params dictionary
                where_clause += ")"
        if sort:
            sort = json.loads(sort)
            if sort:
                for key, value in sort.items():
                    sortField = key
                    sortOrder = value
        query = f"""WITH total_count AS (SELECT COUNT(*) AS count FROM config.ENTITY_DETAILS WHERE 1=1 {where_clause}) 
                SELECT ENTITY_DB,ENTITY_SCHEMA,ENTITY_NAME,S3_PATH,S3_STORAGE_TYPE, (SELECT count FROM total_count) AS total_count
                FROM config.ENTITY_DETAILS WHERE 1=1  {where_clause} ORDER BY {sortField} {sortOrder}
                LIMIT {limit} OFFSET {offset}
                """
        
        cursor.execute(query, params)
        rows = cursor.fetchall()

        data = []
        total = 0
        for row in rows:
            total = row[5]
            data.append({
                'ENTITY_DB': row[0],
                'ENTITY_SCHEMA': row[1],
                'ENTITY_NAME': row[2],
                'S3_PATH': row[3],
                'S3_STORAGE_TYPE': row[4]
            })
        
        cursor.close()
        conn.close()

        return {
            'statusCode': 200,
            'rows': data,
            'page': page,
            'limit': limit,
            'rowCount': total
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({"message": str(e)})
        }
    
if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8080)