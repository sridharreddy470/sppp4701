import { Routes } from '@angular/router';
import { ArchiveComponent } from './archive/archive.component';
import { UnarchiveComponent } from './unarchive/unarchive.component';
import { DeleteComponent } from './delete/delete.component';
import { ConnectionsComponent } from './connections/connections.component';
import { HelpComponent } from './help/help.component';
import { DashboardComponent } from './dashboard/dashboard.component';

export const routes: Routes = [
  { path: 'home', component: DashboardComponent, data: { breadcrumb: 'Home' } },
  { path: 'archive', component: ArchiveComponent, data: { breadcrumb: 'Archive' } },
  { path: 'unarchive', component: UnarchiveComponent, data: { breadcrumb: 'Un-Archive' } },
  { path: 'delete', component: DeleteComponent, data: { breadcrumb: 'Delete' } },
  { path: 'connections', component: ConnectionsComponent, data: { breadcrumb: 'Connections' } },
  { path: 'help', component: HelpComponent, data: { breadcrumb: 'Help' } },
  { path: '', redirectTo: '/home', pathMatch: 'full' },
];