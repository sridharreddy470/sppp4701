import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faTachometerAlt, faTable, faChartLine, faCog, faUsers, faQuestionCircle, faNetworkWired, faCircleChevronLeft, faCircleChevronRight } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-left-nav',
  templateUrl: './left-nav.component.html',
  styleUrls: ['./left-nav.component.scss'],
  imports: [FontAwesomeModule, CommonModule],
  // standalone: true
})
export class LeftNavComponent {
  faTachometerAlt = faTachometerAlt;
  faTable = faTable;
  faChartLine = faChartLine;
  faCog = faCog;
  faUsers = faUsers;
  faQuestionCircle = faQuestionCircle;
  faNetworkWired = faNetworkWired;
  faCircleChevronLeft = faCircleChevronLeft;
  faCircleChevronRight = faCircleChevronRight;

  isCollapsed = false;

  toggleCollapse(): void {
    this.isCollapsed = !this.isCollapsed;
  }

  constructor(private router: Router) {}
  navigateTo(route: string): void {
    this.router.navigate([route]);
  }
}
