import { Component, OnInit, ViewChild } from '@angular/core';
import { GridOptions, IGetRowsParams, GridReadyEvent } from 'ag-grid-community'; // Explicit import
import { DataService } from '../data.service';
import { AgGridModule } from 'ag-grid-angular';
import { faFileUpload, faUpload } from '@fortawesome/free-solid-svg-icons'; // Import the file upload icon
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { CommonModule } from '@angular/common';
import { LoadingService } from '../loading.service';

@Component({
  selector: 'app-archive',
  standalone: true,
  imports: [AgGridModule, FontAwesomeModule, CommonModule],
  templateUrl: './archive.component.html',
  styleUrl: './archive.component.scss'
})
export class ArchiveComponent implements OnInit {
  private gridApi: any;
  private gridColumnApi: any;

  constructor(private loadingService: LoadingService,private dataService: DataService) {}

  filterModel: any[] = [];
  
  sortModel: any = null;
  
  faFileUpload = faFileUpload;
  faUpload = faUpload;
  selectedFile: File | null = null;
  showUploadButton = false;
  fileName: string | null = null;

  gridOptions: GridOptions = {
    rowModelType: 'infinite',
    cacheBlockSize: 50,
    paginationPageSize: 50,
    suppressScrollOnNewData: true,
    getRowId: (params) => params.data.ENTITY_DB.toString(), // Add getRowId
    onGridReady: (params: GridReadyEvent) => {
      this.gridApi = params.api;
      this.gridColumnApi = params.columnApi;
      const dataSource = {
        getRows: (params: IGetRowsParams) => {
          console.log('getRows called:', params.startRow, params.endRow);
          const pageSize = this.gridOptions.paginationPageSize || 10;
          const pageNumber = Math.floor(params.startRow / pageSize) + 1;
          this.loadingService.show();
          this.dataService
            .getData(pageNumber, pageSize,this.filterModel,this.sortModel)
            .subscribe((response) => {
              this.loadingService.hide();
              params.successCallback(response.rows, response.rowCount);
            },(error) => {
              this.loadingService.hide();
            });
        },
      };
      params.api.setGridOption('datasource', dataSource);
    },
    columnDefs: [
      {
        headerName: 'Database',
        field: 'ENTITY_DB',
        sortable: true,
        filter: 'agTextColumnFilter',
        filterParams: { filterOptions: ['contains'] },
      },
      {
        headerName: 'Schema',
        field: 'ENTITY_SCHEMA',
        sortable: true,
        filter: 'agTextColumnFilter',
        filterParams: { filterOptions: ['contains'] },
      },
      {
        headerName: 'Name',
        field: 'ENTITY_NAME',
        sortable: true,
        filter: 'agTextColumnFilter',
        filterParams: { filterOptions: ['contains'] },
      },
      {
        headerName: 'S3 Path',
        field: 'S3_PATH',
        sortable: true,
        filter: 'agTextColumnFilter',
        filterParams: { filterOptions: ['contains'] },
      },
      {
        headerName: 'S3 Storage Type',
        field: 'S3_STORAGE_TYPE',
        sortable: true,
        filter: 'agTextColumnFilter',
        filterParams: { filterOptions: ['contains'] },
      },
    ],
    onFilterChanged: () => {
      this.onFilterChanged();
    },
    onSortChanged: (event:any) => {
      this.sortModel = { [event.columns[0].colId]: event.columns[0].sort };
    }
  };

  ngOnInit(): void {}

  onGridReadyWrapper(event: any) {
    if (this.gridOptions && this.gridOptions.onGridReady) {
      this.gridOptions.onGridReady(event as GridReadyEvent);
    }
  }
  onFilterChanged() {
    const filterModel = this.gridApi.getFilterModel();
    console.log('Filter Model:', filterModel);
    this.filterModel = [];
    
    for (const field in filterModel) {
      const filter = filterModel[field];
      this.filterModel.push({ [field]: filter.filter });
    }
  }
  onFileChange(event: any) {
    this.selectedFile = event.target.files[0];
    if (this.selectedFile) {
      this.fileName = this.selectedFile.name;
      this.showUploadButton = true;
    } else {
      this.fileName = null;
      this.showUploadButton = false;
    }
  }
  uploadFile() {
    if (this.selectedFile) {
      this.showUploadButton = false;
      this.loadingService.show();
      this.dataService.uploadExcel(this.selectedFile)
        .subscribe(response => {
          this.selectedFile = null;          
          const fileInput = document.getElementById('file-upload') as HTMLInputElement;
          if(fileInput){
            fileInput.value = '';
          }
          this.loadingService.hide();
        },(error) => {
          // Handle error
          this.loadingService.hide();
        });
    }
  }
  openFileDialog(): void {
    const fileInput = document.getElementById('file-upload') as HTMLInputElement;
    if (fileInput) {
      fileInput.click();
    }
  }
}
