import { Component } from '@angular/core';

@Component({
  selector: 'app-connections',
  imports: [],
  templateUrl: './connections.component.html',
  styleUrl: './connections.component.scss'
})
export class ConnectionsComponent {

}
