import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class DataService {
  // private apiUrl = 'https://your-api-endpoint.amazonaws.com'; // AWS Lambda API Gateway endpoint
  private apiUrl = 'http://localhost:8080'; // AWS Lambda API Gateway endpoint
  constructor(private http: HttpClient) {}

  uploadExcel(file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file, file.name);
    return this.http.post(`${this.apiUrl}/post-data`, formData);
  }

  getData(page: number=0, limit: number=5, filterModel:any[]=[], sortModel= null): Observable<any> {
    return this.http.get(`${this.apiUrl}/get-data`, {
      params: {
        page: page,
        limit: limit,
        filter: filterModel? JSON.stringify(filterModel):'',
        sort: sortModel != null && Object.keys(sortModel) != null ?JSON.stringify(sortModel): "{\"ENTITY_DB\":\"asc\"}"
      },
    });
  }
}