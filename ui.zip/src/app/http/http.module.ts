import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HttpRoutingModule } from './http-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    HttpRoutingModule
  ]
})
export class HttpModule { }
