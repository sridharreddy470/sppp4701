import { Component } from '@angular/core';

@Component({
  selector: 'app-unarchive',
  imports: [],
  templateUrl: './unarchive.component.html',
  styleUrl: './unarchive.component.scss'
})
export class UnarchiveComponent {

}
